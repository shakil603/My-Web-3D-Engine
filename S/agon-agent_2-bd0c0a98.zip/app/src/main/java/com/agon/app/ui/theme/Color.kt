package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

val SurfaceLight = Color(0xFFF7F9FC)
val SurfaceDark = Color(0xFF0E1116)
val SurfaceContainerLight = Color(0xFFEEF2F7)
val SurfaceContainerDark = Color(0xFF171B22)
