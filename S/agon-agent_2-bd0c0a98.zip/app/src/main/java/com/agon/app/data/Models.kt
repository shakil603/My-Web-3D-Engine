package com.agon.app.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class FileKind {
    FOLDER,
    IMAGE,
    VIDEO,
    AUDIO,
    TEXT,
    CODE,
    PDF,
    MODEL_3D,
    ARCHIVE,
    OTHER
}

enum class SortMode(val label: String) {
    NAME_ASC("Name A–Z"),
    NAME_DESC("Name Z–A"),
    DATE_NEW("Newest first"),
    DATE_OLD("Oldest first"),
    SIZE_LARGE("Largest first"),
    SIZE_SMALL("Smallest first"),
    TYPE("By type")
}

enum class ViewMode { LIST, GRID }

enum class ThemeMode(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark")
}

data class ColorPalette(
    val id: String,
    val name: String,
    val primaryLight: Color,
    val secondaryLight: Color,
    val tertiaryLight: Color,
    val primaryDark: Color,
    val secondaryDark: Color,
    val tertiaryDark: Color,
)

data class FileItem(
    val file: File,
    val name: String = file.name,
    val path: String = file.absolutePath,
    val isDirectory: Boolean = file.isDirectory,
    val size: Long = if (file.isFile) file.length() else 0L,
    val lastModified: Long = file.lastModified(),
    val kind: FileKind = resolveKind(file),
    val extension: String = file.extension.lowercase(Locale.US),
    val isHidden: Boolean = file.isHidden || file.name.startsWith("."),
) {
    val formattedSize: String
        get() = if (isDirectory) "—" else formatBytes(size)

    val formattedDate: String
        get() = DATE_FORMAT.format(Date(lastModified))

    val icon: ImageVector
        get() = when (kind) {
            FileKind.FOLDER -> Icons.Default.Folder
            FileKind.IMAGE -> Icons.Default.Image
            FileKind.VIDEO -> Icons.Default.Movie
            FileKind.AUDIO -> Icons.Default.AudioFile
            FileKind.TEXT -> Icons.Default.Description
            FileKind.CODE -> Icons.Default.Code
            FileKind.PDF -> Icons.Default.PictureAsPdf
            FileKind.MODEL_3D -> Icons.Default.ViewInAr
            FileKind.ARCHIVE -> Icons.Default.Archive
            FileKind.OTHER -> Icons.AutoMirrored.Filled.InsertDriveFile
        }

    companion object {
        private val DATE_FORMAT = SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.getDefault())

        fun resolveKind(file: File): FileKind {
            if (file.isDirectory) return FileKind.FOLDER
            val ext = file.extension.lowercase(Locale.US)
            return when (ext) {
                in IMAGE_EXTS -> FileKind.IMAGE
                in VIDEO_EXTS -> FileKind.VIDEO
                in AUDIO_EXTS -> FileKind.AUDIO
                in CODE_EXTS -> FileKind.CODE
                in TEXT_EXTS -> FileKind.TEXT
                in PDF_EXTS -> FileKind.PDF
                in MODEL_EXTS -> FileKind.MODEL_3D
                in ARCHIVE_EXTS -> FileKind.ARCHIVE
                else -> FileKind.OTHER
            }
        }

        val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg")
        val VIDEO_EXTS = setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "m4v", "flv", "wmv")
        val AUDIO_EXTS = setOf("mp3", "wav", "ogg", "flac", "aac", "m4a", "wma", "opus", "amr")
        val CODE_EXTS = setOf(
            "kt", "java", "py", "js", "ts", "tsx", "jsx", "c", "cpp", "h", "hpp", "cs", "go",
            "rs", "rb", "php", "swift", "scala", "sh", "bash", "zsh", "sql", "html", "css",
            "scss", "xml", "json", "yaml", "yml", "toml", "gradle", "kts", "dart", "lua",
            "r", "m", "mm", "pl", "pm", "vue", "svelte"
        )
        val TEXT_EXTS = setOf(
            "txt", "md", "markdown", "log", "csv", "tsv", "rtf", "ini", "conf", "cfg",
            "properties", "gitignore", "env", "nfo", "readme"
        )
        val PDF_EXTS = setOf("pdf")
        val MODEL_EXTS = setOf("obj", "stl", "gltf", "glb", "ply", "fbx", "3ds", "dae")
        val ARCHIVE_EXTS = setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz", "jar", "apk")
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var i = -1
    while (value >= 1024 && i < units.lastIndex) {
        value /= 1024.0
        i++
    }
    return String.format(Locale.US, "%.1f %s", value, units[i])
}

object ColorPalettes {
    val all = listOf(
        ColorPalette(
            id = "ocean",
            name = "Ocean",
            primaryLight = Color(0xFF006A6A),
            secondaryLight = Color(0xFF4A6363),
            tertiaryLight = Color(0xFF4A607C),
            primaryDark = Color(0xFF4CDADA),
            secondaryDark = Color(0xFFB0CCCC),
            tertiaryDark = Color(0xFFB2C8E8),
        ),
        ColorPalette(
            id = "forest",
            name = "Forest",
            primaryLight = Color(0xFF2E6B3A),
            secondaryLight = Color(0xFF526350),
            tertiaryLight = Color(0xFF3B6471),
            primaryDark = Color(0xFF8FD99A),
            secondaryDark = Color(0xFFB8CDB4),
            tertiaryDark = Color(0xFFA3CDD8),
        ),
        ColorPalette(
            id = "sunset",
            name = "Sunset",
            primaryLight = Color(0xFFA33B00),
            secondaryLight = Color(0xFF77574A),
            tertiaryLight = Color(0xFF6B5A2E),
            primaryDark = Color(0xFFFFB59A),
            secondaryDark = Color(0xFFE7BDB0),
            tertiaryDark = Color(0xFFD7C48A),
        ),
        ColorPalette(
            id = "midnight",
            name = "Midnight",
            primaryLight = Color(0xFF4758A9),
            secondaryLight = Color(0xFF585E76),
            tertiaryLight = Color(0xFF745471),
            primaryDark = Color(0xFFB8C4FF),
            secondaryDark = Color(0xFFC1C5DD),
            tertiaryDark = Color(0xFFE2BADB),
        ),
        ColorPalette(
            id = "rose",
            name = "Rose",
            primaryLight = Color(0xFF9C4146),
            secondaryLight = Color(0xFF775656),
            tertiaryLight = Color(0xFF745B00),
            primaryDark = Color(0xFFFFB3B4),
            secondaryDark = Color(0xFFE6BDBD),
            tertiaryDark = Color(0xFFE9C349),
        ),
        ColorPalette(
            id = "amber",
            name = "Amber",
            primaryLight = Color(0xFF7C5800),
            secondaryLight = Color(0xFF6B5D3F),
            tertiaryLight = Color(0xFF4C6545),
            primaryDark = Color(0xFFF5BE48),
            secondaryDark = Color(0xFFD8C5A0),
            tertiaryDark = Color(0xFFB2CFA8),
        ),
        ColorPalette(
            id = "slate",
            name = "Slate",
            primaryLight = Color(0xFF4A5D73),
            secondaryLight = Color(0xFF5B5F66),
            tertiaryLight = Color(0xFF6A5770),
            primaryDark = Color(0xFFB2C8E2),
            secondaryDark = Color(0xFFC4C6CD),
            tertiaryDark = Color(0xFFD6BEE5),
        ),
        ColorPalette(
            id = "violet",
            name = "Violet",
            primaryLight = Color(0xFF6B4FA0),
            secondaryLight = Color(0xFF655A75),
            tertiaryLight = Color(0xFF82536A),
            primaryDark = Color(0xFFD4BBFF),
            secondaryDark = Color(0xFFCFC2DC),
            tertiaryDark = Color(0xFFF5B5CE),
        ),
        ColorPalette(
            id = "coral",
            name = "Coral",
            primaryLight = Color(0xFFB23A4A),
            secondaryLight = Color(0xFF7A5560),
            tertiaryLight = Color(0xFF6E5C2E),
            primaryDark = Color(0xFFFFB2B9),
            secondaryDark = Color(0xFFEBBBC5),
            tertiaryDark = Color(0xFFD8C68A),
        ),
        ColorPalette(
            id = "mint",
            name = "Mint",
            primaryLight = Color(0xFF006B5E),
            secondaryLight = Color(0xFF4A635E),
            tertiaryLight = Color(0xFF4A6072),
            primaryDark = Color(0xFF5CDBCB),
            secondaryDark = Color(0xFFB0CCC5),
            tertiaryDark = Color(0xFFB2C8DD),
        ),
    )

    fun byId(id: String): ColorPalette = all.find { it.id == id } ?: all.first()
}

data class StorageShortcut(
    val id: String,
    val title: String,
    val path: String,
    val iconKind: FileKind,
)

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val paletteId: String = "ocean",
    val backgroundImagePath: String? = null,
    val backgroundDim: Float = 0.55f,
    val viewMode: ViewMode = ViewMode.LIST,
    val sortMode: SortMode = SortMode.NAME_ASC,
    val showHidden: Boolean = false,
    val favorites: Set<String> = emptySet(),
    val recentPaths: List<String> = emptyList(),
)
