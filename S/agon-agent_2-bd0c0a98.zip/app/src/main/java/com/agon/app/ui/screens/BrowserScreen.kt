package com.agon.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.agon.app.data.FileItem
import com.agon.app.data.SortMode
import com.agon.app.data.ViewMode
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.FileGridCell
import com.agon.app.ui.components.FileListRow
import com.agon.app.ui.components.PathBreadcrumb
import com.agon.app.viewmodel.FileViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(
    vm: FileViewModel,
    onOpenFile: (FileItem) -> Unit,
) {
    val browser by vm.browser.collectAsState()
    val settings by vm.settings.collectAsState()
    val items = vm.displayItems(browser)
    var menuOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    var showNewFolder by remember { mutableStateOf(false) }
    var showNewFile by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var nameInput by remember { mutableStateOf("") }
    val focus = LocalFocusManager.current

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    if (browser.isSearching) {
                        TextField(
                            value = browser.searchQuery,
                            onValueChange = { vm.setSearchQuery(it) },
                            placeholder = { Text("Search all files…") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
                        )
                    } else {
                        Column {
                            Text(
                                browser.categoryTitle
                                    ?: browser.currentPath.substringAfterLast('/').ifBlank { "Storage" },
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                            )
                            if (browser.categoryTitle == null) {
                                PathBreadcrumb(browser.currentPath)
                            } else {
                                Text(
                                    "${items.size} items",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    when {
                        browser.isSearching -> {
                            IconButton(onClick = { vm.setSearching(false) }) {
                                Icon(Icons.Default.Close, contentDescription = "Close search")
                            }
                        }
                        browser.selectionMode -> {
                            IconButton(onClick = { vm.clearSelection() }) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel")
                            }
                        }
                        browser.categoryKind != null -> {
                            IconButton(onClick = { vm.clearCategory() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                        }
                        browser.canGoUp -> {
                            IconButton(onClick = { vm.goUp() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Up")
                            }
                        }
                    }
                },
                actions = {
                    if (browser.selectionMode) {
                        IconButton(onClick = { vm.selectAll() }) {
                            Icon(Icons.Default.SelectAll, contentDescription = "Select all")
                        }
                        IconButton(onClick = { vm.copySelected() }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                        }
                        IconButton(onClick = { vm.cutSelected() }) {
                            Icon(Icons.Default.ContentCut, contentDescription = "Cut")
                        }
                        IconButton(onClick = { showDelete = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                        if (browser.selectedPaths.size == 1) {
                            IconButton(onClick = {
                                nameInput = browser.selectedPaths.first().substringAfterLast('/')
                                showRename = true
                            }) {
                                Icon(Icons.Default.DriveFileRenameOutline, contentDescription = "Rename")
                            }
                            val path = browser.selectedPaths.first()
                            IconButton(onClick = { vm.toggleFavorite(path) }) {
                                Icon(
                                    if (settings.favorites.contains(path)) Icons.Default.Star
                                    else Icons.Default.StarBorder,
                                    contentDescription = "Favorite",
                                )
                            }
                        }
                    } else {
                        IconButton(onClick = { vm.setSearching(true) }) {
                            Icon(Icons.Default.Search, contentDescription = "Search")
                        }
                        IconButton(onClick = {
                            vm.setViewMode(
                                if (settings.viewMode == ViewMode.LIST) ViewMode.GRID else ViewMode.LIST,
                            )
                        }) {
                            Icon(
                                if (settings.viewMode == ViewMode.LIST) Icons.Default.GridView
                                else Icons.Default.ViewList,
                                contentDescription = "View mode",
                            )
                        }
                        Box {
                            IconButton(onClick = { sortOpen = true }) {
                                Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort")
                            }
                            DropdownMenu(expanded = sortOpen, onDismissRequest = { sortOpen = false }) {
                                SortMode.entries.forEach { mode ->
                                    DropdownMenuItem(
                                        text = { Text(mode.label) },
                                        onClick = {
                                            vm.setSortMode(mode)
                                            sortOpen = false
                                        },
                                    )
                                }
                            }
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More")
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("New folder") },
                                    leadingIcon = { Icon(Icons.Default.CreateNewFolder, null) },
                                    onClick = {
                                        menuOpen = false
                                        nameInput = ""
                                        showNewFolder = true
                                    },
                                )
                                DropdownMenuItem(
                                    text = { Text("New file") },
                                    leadingIcon = { Icon(Icons.Default.NoteAdd, null) },
                                    onClick = {
                                        menuOpen = false
                                        nameInput = ""
                                        showNewFile = true
                                    },
                                )
                                if (browser.clipboardPaths.isNotEmpty()) {
                                    DropdownMenuItem(
                                        text = { Text("Paste (${browser.clipboardPaths.size})") },
                                        leadingIcon = { Icon(Icons.Default.ContentPaste, null) },
                                        onClick = {
                                            menuOpen = false
                                            vm.paste()
                                        },
                                    )
                                }
                                DropdownMenuItem(
                                    text = {
                                        Text(if (settings.showHidden) "Hide hidden files" else "Show hidden files")
                                    },
                                    leadingIcon = {
                                        Icon(
                                            if (settings.showHidden) Icons.Default.VisibilityOff
                                            else Icons.Default.Visibility,
                                            null,
                                        )
                                    },
                                    onClick = {
                                        menuOpen = false
                                        vm.setShowHidden(!settings.showHidden)
                                    },
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                ),
            )
        },
        floatingActionButton = {
            AnimatedVisibility(visible = browser.clipboardPaths.isNotEmpty() && !browser.selectionMode) {
                FloatingActionButton(
                    onClick = { vm.paste() },
                    containerColor = MaterialTheme.colorScheme.primary,
                    elevation = FloatingActionButtonDefaults.elevation(4.dp),
                ) {
                    Icon(Icons.Default.ContentPaste, contentDescription = "Paste")
                }
            }
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when {
                browser.isLoading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                browser.error != null -> {
                    EmptyState(
                        title = "Access denied",
                        subtitle = browser.error ?: "",
                        modifier = Modifier.align(Alignment.Center),
                    )
                }
                items.isEmpty() -> {
                    EmptyState(
                        title = if (browser.isSearching) "No results" else "Empty folder",
                        subtitle = if (browser.isSearching) "Try another keyword"
                        else "Create a file or folder to get started",
                        modifier = Modifier.align(Alignment.Center),
                    )
                }
                settings.viewMode == ViewMode.GRID && !browser.isSearching -> {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(120.dp),
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(items, key = { it.path }) { item ->
                            FileGridCell(
                                item = item,
                                selected = browser.selectedPaths.contains(item.path),
                                selectionMode = browser.selectionMode,
                                onClick = {
                                    when {
                                        browser.selectionMode -> vm.toggleSelection(item.path)
                                        item.isDirectory -> vm.openItem(item)
                                        else -> {
                                            vm.openItem(item)
                                            onOpenFile(item)
                                        }
                                    }
                                },
                                onLongClick = { vm.toggleSelection(item.path) },
                            )
                        }
                    }
                }
                else -> {
                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        if (browser.selectionMode) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Text(
                                        "${browser.selectedPaths.size} selected",
                                        modifier = Modifier.padding(12.dp),
                                        fontWeight = FontWeight.Medium,
                                    )
                                }
                            }
                        }
                        items(items, key = { it.path }) { item ->
                            FileListRow(
                                item = item,
                                selected = browser.selectedPaths.contains(item.path),
                                selectionMode = browser.selectionMode,
                                isFavorite = settings.favorites.contains(item.path),
                                onClick = {
                                    when {
                                        browser.selectionMode -> vm.toggleSelection(item.path)
                                        item.isDirectory -> vm.openItem(item)
                                        else -> {
                                            vm.openItem(item)
                                            onOpenFile(item)
                                        }
                                    }
                                },
                                onLongClick = { vm.toggleSelection(item.path) },
                            )
                        }
                        item { Spacer(modifier = Modifier.height(80.dp)) }
                    }
                }
            }
        }
    }

    if (showNewFolder) {
        NameDialog(
            title = "New folder",
            value = nameInput,
            onValueChange = { nameInput = it },
            onConfirm = {
                vm.createFolder(nameInput.trim())
                showNewFolder = false
            },
            onDismiss = { showNewFolder = false },
        )
    }
    if (showNewFile) {
        NameDialog(
            title = "New file",
            value = nameInput,
            onValueChange = { nameInput = it },
            onConfirm = {
                vm.createFile(nameInput.trim())
                showNewFile = false
            },
            onDismiss = { showNewFile = false },
        )
    }
    if (showRename && browser.selectedPaths.size == 1) {
        NameDialog(
            title = "Rename",
            value = nameInput,
            onValueChange = { nameInput = it },
            onConfirm = {
                vm.rename(browser.selectedPaths.first(), nameInput.trim())
                showRename = false
            },
            onDismiss = { showRename = false },
        )
    }
    if (showDelete) {
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete ${browser.selectedPaths.size} item(s)?") },
            text = { Text("This action cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteSelected()
                    showDelete = false
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDelete = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun NameDialog(
    title: String,
    value: String,
    onValueChange: (String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = value.isNotBlank()) { Text("OK") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}
