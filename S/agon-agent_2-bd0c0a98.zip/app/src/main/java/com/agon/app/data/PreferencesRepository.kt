package com.agon.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "file_settings")

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val themeMode = stringPreferencesKey("theme_mode")
        val paletteId = stringPreferencesKey("palette_id")
        val backgroundImage = stringPreferencesKey("background_image")
        val backgroundDim = floatPreferencesKey("background_dim")
        val viewMode = stringPreferencesKey("view_mode")
        val sortMode = stringPreferencesKey("sort_mode")
        val showHidden = booleanPreferencesKey("show_hidden")
        val favorites = stringSetPreferencesKey("favorites")
        val recentPaths = stringPreferencesKey("recent_paths")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            themeMode = runCatching {
                ThemeMode.valueOf(prefs[Keys.themeMode] ?: ThemeMode.SYSTEM.name)
            }.getOrDefault(ThemeMode.SYSTEM),
            paletteId = prefs[Keys.paletteId] ?: "ocean",
            backgroundImagePath = prefs[Keys.backgroundImage],
            backgroundDim = prefs[Keys.backgroundDim] ?: 0.55f,
            viewMode = runCatching {
                ViewMode.valueOf(prefs[Keys.viewMode] ?: ViewMode.LIST.name)
            }.getOrDefault(ViewMode.LIST),
            sortMode = runCatching {
                SortMode.valueOf(prefs[Keys.sortMode] ?: SortMode.NAME_ASC.name)
            }.getOrDefault(SortMode.NAME_ASC),
            showHidden = prefs[Keys.showHidden] ?: false,
            favorites = prefs[Keys.favorites] ?: emptySet(),
            recentPaths = (prefs[Keys.recentPaths] ?: "")
                .split("|")
                .filter { it.isNotBlank() },
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.themeMode] = mode.name }
    }

    suspend fun setPalette(id: String) {
        context.dataStore.edit { it[Keys.paletteId] = id }
    }

    suspend fun setBackgroundImage(path: String?) {
        context.dataStore.edit {
            if (path == null) it.remove(Keys.backgroundImage)
            else it[Keys.backgroundImage] = path
        }
    }

    suspend fun setBackgroundDim(dim: Float) {
        context.dataStore.edit { it[Keys.backgroundDim] = dim.coerceIn(0.2f, 0.9f) }
    }

    suspend fun setViewMode(mode: ViewMode) {
        context.dataStore.edit { it[Keys.viewMode] = mode.name }
    }

    suspend fun setSortMode(mode: SortMode) {
        context.dataStore.edit { it[Keys.sortMode] = mode.name }
    }

    suspend fun setShowHidden(show: Boolean) {
        context.dataStore.edit { it[Keys.showHidden] = show }
    }

    suspend fun toggleFavorite(path: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.favorites]?.toMutableSet() ?: mutableSetOf()
            if (current.contains(path)) current.remove(path) else current.add(path)
            prefs[Keys.favorites] = current
        }
    }

    suspend fun addRecent(path: String) {
        context.dataStore.edit { prefs ->
            val current = (prefs[Keys.recentPaths] ?: "")
                .split("|")
                .filter { it.isNotBlank() && it != path }
                .toMutableList()
            current.add(0, path)
            prefs[Keys.recentPaths] = current.take(20).joinToString("|")
        }
    }

    suspend fun clearRecents() {
        context.dataStore.edit { it[Keys.recentPaths] = "" }
    }
}
