package com.agon.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.AppSettings
import com.agon.app.data.FileItem
import com.agon.app.data.FileKind
import com.agon.app.data.FileRepository
import com.agon.app.data.PreferencesRepository
import com.agon.app.data.SortMode
import com.agon.app.data.StorageInfo
import com.agon.app.data.StorageShortcut
import com.agon.app.data.ThemeMode
import com.agon.app.data.ViewMode
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class BrowserUiState(
    val currentPath: String = "",
    val items: List<FileItem> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val searchResults: List<FileItem> = emptyList(),
    val selectedPaths: Set<String> = emptySet(),
    val selectionMode: Boolean = false,
    val clipboardPaths: List<String> = emptyList(),
    val clipboardIsCut: Boolean = false,
    val categoryKind: FileKind? = null,
    val categoryTitle: String? = null,
    val canGoUp: Boolean = false,
)

class FileViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = PreferencesRepository(application)
    private val files = FileRepository(application)

    val settings: StateFlow<AppSettings> = prefs.settings.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        AppSettings(),
    )

    private val _browser = MutableStateFlow(BrowserUiState())
    val browser: StateFlow<BrowserUiState> = _browser.asStateFlow()

    private val _storageInfo = MutableStateFlow(StorageInfo(0, 0, 0))
    val storageInfo: StateFlow<StorageInfo> = _storageInfo.asStateFlow()

    private val _shortcuts = MutableStateFlow<List<StorageShortcut>>(emptyList())
    val shortcuts: StateFlow<List<StorageShortcut>> = _shortcuts.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private var searchJob: Job? = null
    private var loadJob: Job? = null

    init {
        val root = files.internalStorageRoot().absolutePath
        _browser.update { it.copy(currentPath = root) }
        refreshShortcuts()
        refreshStorage()
        viewModelScope.launch {
            settings.collect { loadCurrent() }
        }
    }

    fun refreshShortcuts() {
        _shortcuts.value = files.shortcuts()
    }

    fun refreshStorage() {
        _storageInfo.value = files.getStorageInfo()
    }

    fun navigateTo(path: String) {
        _browser.update {
            it.copy(
                currentPath = path,
                searchQuery = "",
                isSearching = false,
                searchResults = emptyList(),
                categoryKind = null,
                categoryTitle = null,
                selectedPaths = emptySet(),
                selectionMode = false,
            )
        }
        loadCurrent()
    }

    fun goUp() {
        val parent = files.parentPath(_browser.value.currentPath) ?: return
        navigateTo(parent)
    }

    fun openItem(item: FileItem) {
        if (item.isDirectory) {
            navigateTo(item.path)
        } else {
            viewModelScope.launch { prefs.addRecent(item.path) }
        }
    }

    fun loadCurrent() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            val state = _browser.value
            _browser.update { it.copy(isLoading = true, error = null) }
            val s = settings.value
            val result = withContext(Dispatchers.IO) {
                when {
                    state.categoryKind != null -> {
                        files.findByKind(
                            files.internalStorageRoot().absolutePath,
                            state.categoryKind,
                            s.showHidden,
                        ).let { files.sort(it, s.sortMode) }
                    }
                    else -> files.listFiles(
                        state.currentPath,
                        s.showHidden,
                        s.sortMode,
                        if (state.isSearching) "" else state.searchQuery,
                    )
                }
            }
            val canUp = state.categoryKind == null &&
                files.parentPath(state.currentPath) != null &&
                File(state.currentPath).absolutePath != "/"
            _browser.update {
                it.copy(
                    items = result,
                    isLoading = false,
                    canGoUp = canUp,
                    error = if (!File(state.currentPath).canRead() && state.categoryKind == null)
                        "Cannot read this folder. Grant storage permission."
                    else null,
                )
            }
        }
    }

    fun openCategory(kind: FileKind, title: String) {
        _browser.update {
            it.copy(
                categoryKind = kind,
                categoryTitle = title,
                searchQuery = "",
                isSearching = false,
                selectedPaths = emptySet(),
                selectionMode = false,
            )
        }
        loadCurrent()
    }

    fun clearCategory() {
        _browser.update { it.copy(categoryKind = null, categoryTitle = null) }
        loadCurrent()
    }

    fun setSearchQuery(query: String) {
        _browser.update { it.copy(searchQuery = query) }
        if (_browser.value.isSearching) {
            searchJob?.cancel()
            searchJob = viewModelScope.launch {
                delay(280)
                val s = settings.value
                val results = withContext(Dispatchers.IO) {
                    files.search(
                        files.internalStorageRoot().absolutePath,
                        query,
                        s.showHidden,
                    )
                }
                _browser.update { it.copy(searchResults = results) }
            }
        } else {
            loadCurrent()
        }
    }

    fun setSearching(active: Boolean) {
        _browser.update {
            it.copy(
                isSearching = active,
                searchQuery = if (active) it.searchQuery else "",
                searchResults = emptyList(),
            )
        }
        if (!active) loadCurrent()
    }

    fun toggleSelection(path: String) {
        _browser.update { state ->
            val next = state.selectedPaths.toMutableSet()
            if (next.contains(path)) next.remove(path) else next.add(path)
            state.copy(
                selectedPaths = next,
                selectionMode = next.isNotEmpty(),
            )
        }
    }

    fun selectAll() {
        _browser.update { state ->
            val paths = displayItems(state).map { it.path }.toSet()
            state.copy(selectedPaths = paths, selectionMode = paths.isNotEmpty())
        }
    }

    fun clearSelection() {
        _browser.update { it.copy(selectedPaths = emptySet(), selectionMode = false) }
    }

    fun displayItems(state: BrowserUiState = _browser.value): List<FileItem> {
        return if (state.isSearching) state.searchResults else state.items
    }

    fun copySelected() {
        val paths = _browser.value.selectedPaths.toList()
        if (paths.isEmpty()) return
        _browser.update {
            it.copy(
                clipboardPaths = paths,
                clipboardIsCut = false,
                selectedPaths = emptySet(),
                selectionMode = false,
            )
        }
        _message.value = "Copied ${paths.size} item(s)"
    }

    fun cutSelected() {
        val paths = _browser.value.selectedPaths.toList()
        if (paths.isEmpty()) return
        _browser.update {
            it.copy(
                clipboardPaths = paths,
                clipboardIsCut = true,
                selectedPaths = emptySet(),
                selectionMode = false,
            )
        }
        _message.value = "Cut ${paths.size} item(s)"
    }

    fun paste() {
        val state = _browser.value
        if (state.clipboardPaths.isEmpty()) return
        viewModelScope.launch {
            val dest = state.currentPath
            var ok = 0
            withContext(Dispatchers.IO) {
                state.clipboardPaths.forEach { src ->
                    val success = if (state.clipboardIsCut) {
                        files.moveFile(src, dest)
                    } else {
                        files.copyFile(src, dest)
                    }
                    if (success) ok++
                }
            }
            if (state.clipboardIsCut) {
                _browser.update { it.copy(clipboardPaths = emptyList(), clipboardIsCut = false) }
            }
            _message.value = "Pasted $ok item(s)"
            loadCurrent()
            refreshStorage()
        }
    }

    fun deleteSelected() {
        val paths = _browser.value.selectedPaths.toList()
        if (paths.isEmpty()) return
        viewModelScope.launch {
            var ok = 0
            withContext(Dispatchers.IO) {
                paths.forEach { if (files.delete(it)) ok++ }
            }
            _browser.update { it.copy(selectedPaths = emptySet(), selectionMode = false) }
            _message.value = "Deleted $ok item(s)"
            loadCurrent()
            refreshStorage()
        }
    }

    fun rename(path: String, newName: String) {
        viewModelScope.launch {
            val success = withContext(Dispatchers.IO) { files.rename(path, newName) }
            _message.value = if (success) "Renamed" else "Rename failed"
            clearSelection()
            loadCurrent()
        }
    }

    fun createFolder(name: String) {
        viewModelScope.launch {
            val path = _browser.value.currentPath
            val success = withContext(Dispatchers.IO) { files.createFolder(path, name) }
            _message.value = if (success) "Folder created" else "Could not create folder"
            loadCurrent()
        }
    }

    fun createFile(name: String) {
        viewModelScope.launch {
            val path = _browser.value.currentPath
            val success = withContext(Dispatchers.IO) { files.createFile(path, name) }
            _message.value = if (success) "File created" else "Could not create file"
            loadCurrent()
        }
    }

    fun toggleFavorite(path: String) {
        viewModelScope.launch { prefs.toggleFavorite(path) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefs.setThemeMode(mode) }
    }

    fun setPalette(id: String) {
        viewModelScope.launch { prefs.setPalette(id) }
    }

    fun setBackgroundImage(path: String?) {
        viewModelScope.launch { prefs.setBackgroundImage(path) }
    }

    fun setBackgroundDim(dim: Float) {
        viewModelScope.launch { prefs.setBackgroundDim(dim) }
    }

    fun setViewMode(mode: ViewMode) {
        viewModelScope.launch { prefs.setViewMode(mode) }
    }

    fun setSortMode(mode: SortMode) {
        viewModelScope.launch { prefs.setSortMode(mode) }
    }

    fun setShowHidden(show: Boolean) {
        viewModelScope.launch { prefs.setShowHidden(show) }
    }

    fun clearRecents() {
        viewModelScope.launch { prefs.clearRecents() }
    }

    fun consumeMessage() {
        _message.value = null
    }

    fun favoriteItems(): List<FileItem> {
        return settings.value.favorites.mapNotNull { path ->
            val f = File(path)
            if (f.exists()) FileItem(f) else null
        }.sortedBy { it.name.lowercase() }
    }

    fun recentItems(): List<FileItem> {
        return settings.value.recentPaths.mapNotNull { path ->
            val f = File(path)
            if (f.exists()) FileItem(f) else null
        }
    }

    fun readText(path: String): String = files.readTextPreview(path)

    fun readHex(path: String): String = files.readHexPreview(path)
}
