package com.agon.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.agon.app.data.ColorPalette
import com.agon.app.data.ColorPalettes
import com.agon.app.data.ThemeMode

@Composable
fun AgonAppTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    paletteId: String = "ocean",
    content: @Composable () -> Unit,
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val palette = ColorPalettes.byId(paletteId)
    val colorScheme = if (darkTheme) darkScheme(palette) else lightScheme(palette)
    MaterialTheme(colorScheme = colorScheme, content = content)
}

private fun lightScheme(p: ColorPalette) = lightColorScheme(
    primary = p.primaryLight,
    onPrimary = Color.White,
    primaryContainer = p.primaryLight.copy(alpha = 0.18f),
    onPrimaryContainer = p.primaryLight,
    secondary = p.secondaryLight,
    onSecondary = Color.White,
    secondaryContainer = p.secondaryLight.copy(alpha = 0.16f),
    onSecondaryContainer = p.secondaryLight,
    tertiary = p.tertiaryLight,
    onTertiary = Color.White,
    tertiaryContainer = p.tertiaryLight.copy(alpha = 0.16f),
    onTertiaryContainer = p.tertiaryLight,
    background = SurfaceLight,
    onBackground = Color(0xFF12151A),
    surface = SurfaceLight,
    onSurface = Color(0xFF12151A),
    surfaceVariant = SurfaceContainerLight,
    onSurfaceVariant = Color(0xFF4A5360),
    outline = Color(0xFF7A8494),
    outlineVariant = Color(0xFFD0D7E2),
    error = Color(0xFFBA1A1A),
    onError = Color.White,
)

private fun darkScheme(p: ColorPalette) = darkColorScheme(
    primary = p.primaryDark,
    onPrimary = Color(0xFF003738),
    primaryContainer = p.primaryDark.copy(alpha = 0.22f),
    onPrimaryContainer = p.primaryDark,
    secondary = p.secondaryDark,
    onSecondary = Color(0xFF1B3333),
    secondaryContainer = p.secondaryDark.copy(alpha = 0.18f),
    onSecondaryContainer = p.secondaryDark,
    tertiary = p.tertiaryDark,
    onTertiary = Color(0xFF1E2E3F),
    tertiaryContainer = p.tertiaryDark.copy(alpha = 0.18f),
    onTertiaryContainer = p.tertiaryDark,
    background = SurfaceDark,
    onBackground = Color(0xFFE4E8EF),
    surface = SurfaceDark,
    onSurface = Color(0xFFE4E8EF),
    surfaceVariant = SurfaceContainerDark,
    onSurfaceVariant = Color(0xFFA8B0BD),
    outline = Color(0xFF8A93A1),
    outlineVariant = Color(0xFF2A313C),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
)
