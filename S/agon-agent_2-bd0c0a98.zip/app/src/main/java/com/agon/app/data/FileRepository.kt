package com.agon.app.data

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.util.Locale

data class StorageInfo(
    val totalBytes: Long,
    val freeBytes: Long,
    val usedBytes: Long,
) {
    val usedFraction: Float
        get() = if (totalBytes == 0L) 0f else usedBytes.toFloat() / totalBytes.toFloat()
}

class FileRepository(private val context: Context) {

    fun internalStorageRoot(): File =
        Environment.getExternalStorageDirectory() ?: File("/storage/emulated/0")

    fun getStorageInfo(root: File = internalStorageRoot()): StorageInfo {
        return try {
            val stat = StatFs(root.absolutePath)
            val total = stat.blockCountLong * stat.blockSizeLong
            val free = stat.availableBlocksLong * stat.blockSizeLong
            StorageInfo(total, free, total - free)
        } catch (_: Exception) {
            StorageInfo(0, 0, 0)
        }
    }

    fun shortcuts(): List<StorageShortcut> {
        val root = internalStorageRoot()
        val list = mutableListOf(
            StorageShortcut("internal", "Internal storage", root.absolutePath, FileKind.FOLDER),
            StorageShortcut(
                "downloads",
                "Downloads",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath,
                FileKind.FOLDER,
            ),
            StorageShortcut(
                "dcim",
                "Camera",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath,
                FileKind.IMAGE,
            ),
            StorageShortcut(
                "pictures",
                "Pictures",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath,
                FileKind.IMAGE,
            ),
            StorageShortcut(
                "movies",
                "Movies",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).absolutePath,
                FileKind.VIDEO,
            ),
            StorageShortcut(
                "music",
                "Music",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).absolutePath,
                FileKind.AUDIO,
            ),
            StorageShortcut(
                "documents",
                "Documents",
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).absolutePath,
                FileKind.TEXT,
            ),
            StorageShortcut(
                "app",
                "App files",
                context.getExternalFilesDir(null)?.absolutePath ?: context.filesDir.absolutePath,
                FileKind.FOLDER,
            ),
        )
        return list.filter { File(it.path).exists() || it.id == "app" || it.id == "internal" }
    }

    fun listFiles(
        path: String,
        showHidden: Boolean,
        sortMode: SortMode,
        query: String = "",
    ): List<FileItem> {
        val dir = File(path)
        if (!dir.exists() || !dir.isDirectory || !dir.canRead()) return emptyList()

        val q = query.trim().lowercase(Locale.US)
        val items = dir.listFiles()
            ?.asSequence()
            ?.map { FileItem(it) }
            ?.filter { showHidden || !it.isHidden }
            ?.filter { q.isEmpty() || it.name.lowercase(Locale.US).contains(q) }
            ?.toList()
            ?: emptyList()

        return sort(items, sortMode)
    }

    fun sort(items: List<FileItem>, sortMode: SortMode): List<FileItem> {
        val foldersFirst = Comparator<FileItem> { a, b ->
            when {
                a.isDirectory && !b.isDirectory -> -1
                !a.isDirectory && b.isDirectory -> 1
                else -> 0
            }
        }
        val secondary = when (sortMode) {
            SortMode.NAME_ASC -> compareBy<FileItem> { it.name.lowercase(Locale.US) }
            SortMode.NAME_DESC -> compareByDescending { it.name.lowercase(Locale.US) }
            SortMode.DATE_NEW -> compareByDescending { it.lastModified }
            SortMode.DATE_OLD -> compareBy { it.lastModified }
            SortMode.SIZE_LARGE -> compareByDescending { it.size }
            SortMode.SIZE_SMALL -> compareBy { it.size }
            SortMode.TYPE -> compareBy<FileItem> { it.kind.ordinal }.thenBy { it.extension }
        }
        return items.sortedWith(foldersFirst.then(secondary))
    }

    fun search(
        rootPath: String,
        query: String,
        showHidden: Boolean,
        maxResults: Int = 200,
    ): List<FileItem> {
        val q = query.trim().lowercase(Locale.US)
        if (q.isEmpty()) return emptyList()
        val results = mutableListOf<FileItem>()
        val root = File(rootPath)
        if (!root.exists()) return emptyList()

        fun walk(dir: File, depth: Int) {
            if (results.size >= maxResults || depth > 8) return
            val files = dir.listFiles() ?: return
            for (f in files) {
                if (results.size >= maxResults) return
                val hidden = f.isHidden || f.name.startsWith(".")
                if (!showHidden && hidden) continue
                if (f.name.lowercase(Locale.US).contains(q)) {
                    results.add(FileItem(f))
                }
                if (f.isDirectory) walk(f, depth + 1)
            }
        }
        walk(root, 0)
        return results.sortedBy { it.name.lowercase(Locale.US) }
    }

    fun findByKind(
        rootPath: String,
        kind: FileKind,
        showHidden: Boolean,
        maxResults: Int = 300,
    ): List<FileItem> {
        val results = mutableListOf<FileItem>()
        val root = File(rootPath)
        if (!root.exists()) return emptyList()

        fun walk(dir: File, depth: Int) {
            if (results.size >= maxResults || depth > 6) return
            val files = try {
                dir.listFiles() ?: return
            } catch (_: Exception) {
                return
            }
            for (f in files) {
                if (results.size >= maxResults) return
                val hidden = f.isHidden || f.name.startsWith(".")
                if (!showHidden && hidden) continue
                if (f.isDirectory) {
                    walk(f, depth + 1)
                } else {
                    val item = FileItem(f)
                    if (item.kind == kind) results.add(item)
                }
            }
        }
        walk(root, 0)
        return results.sortedByDescending { it.lastModified }
    }

    fun rename(path: String, newName: String): Boolean {
        val file = File(path)
        if (!file.exists() || newName.isBlank()) return false
        val target = File(file.parentFile, newName)
        if (target.exists()) return false
        return file.renameTo(target)
    }

    fun delete(path: String): Boolean {
        val file = File(path)
        if (!file.exists()) return false
        return if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    fun createFolder(parentPath: String, name: String): Boolean {
        if (name.isBlank()) return false
        val dir = File(parentPath, name)
        return !dir.exists() && dir.mkdirs()
    }

    fun createFile(parentPath: String, name: String): Boolean {
        if (name.isBlank()) return false
        val file = File(parentPath, name)
        return try {
            !file.exists() && file.createNewFile()
        } catch (_: Exception) {
            false
        }
    }

    fun copyFile(sourcePath: String, destDirPath: String): Boolean {
        return try {
            val src = File(sourcePath)
            val destDir = File(destDirPath)
            if (!src.exists() || !destDir.isDirectory) return false
            val dest = uniqueName(File(destDir, src.name))
            src.copyRecursively(dest, overwrite = false)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun moveFile(sourcePath: String, destDirPath: String): Boolean {
        return try {
            val src = File(sourcePath)
            val destDir = File(destDirPath)
            if (!src.exists() || !destDir.isDirectory) return false
            val dest = uniqueName(File(destDir, src.name))
            if (src.renameTo(dest)) true
            else {
                src.copyRecursively(dest, overwrite = false)
                src.deleteRecursively()
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun uniqueName(file: File): File {
        if (!file.exists()) return file
        val parent = file.parentFile ?: return file
        val base = file.nameWithoutExtension
        val ext = if (file.extension.isNotEmpty()) ".${file.extension}" else ""
        var i = 1
        var candidate: File
        do {
            candidate = File(parent, "$base ($i)$ext")
            i++
        } while (candidate.exists())
        return candidate
    }

    fun readTextPreview(path: String, maxChars: Int = 200_000): String {
        return try {
            val file = File(path)
            if (!file.exists() || !file.isFile) return ""
            file.bufferedReader().use { reader ->
                val sb = StringBuilder()
                val buf = CharArray(8192)
                var total = 0
                while (total < maxChars) {
                    val read = reader.read(buf, 0, minOf(buf.size, maxChars - total))
                    if (read <= 0) break
                    sb.append(buf, 0, read)
                    total += read
                }
                if (reader.read() != -1) sb.append("\n\n… (file truncated for preview)")
                sb.toString()
            }
        } catch (e: Exception) {
            "Unable to read file: ${e.message}"
        }
    }

    fun readHexPreview(path: String, maxBytes: Int = 4096): String {
        return try {
            val file = File(path)
            val bytes = file.inputStream().use { stream ->
                val buffer = ByteArray(maxBytes)
                var read = 0
                while (read < maxBytes) {
                    val n = stream.read(buffer, read, maxBytes - read)
                    if (n <= 0) break
                    read += n
                }
                if (read == maxBytes) buffer else buffer.copyOf(read)
            }
            val sb = StringBuilder()
            var offset = 0
            while (offset < bytes.size) {
                sb.append(String.format(Locale.US, "%08X  ", offset))
                val lineEnd = minOf(offset + 16, bytes.size)
                for (i in offset until offset + 16) {
                    if (i < lineEnd) sb.append(String.format(Locale.US, "%02X ", bytes[i].toInt() and 0xFF))
                    else sb.append("   ")
                    if (i == offset + 7) sb.append(" ")
                }
                sb.append(" |")
                for (i in offset until lineEnd) {
                    val b = bytes[i].toInt() and 0xFF
                    sb.append(if (b in 32..126) b.toChar() else '.')
                }
                sb.append("|\n")
                offset += 16
            }
            if (file.length() > maxBytes) sb.append("\n… truncated")
            sb.toString()
        } catch (e: Exception) {
            "Unable to read binary: ${e.message}"
        }
    }

    fun parentPath(path: String): String? {
        val parent = File(path).parentFile ?: return null
        return parent.absolutePath
    }
}
