package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.agon.app.data.FileItem
import com.agon.app.data.FileKind
import com.agon.app.ui.components.AppBackground
import com.agon.app.ui.player.UniversalPlayerScreen
import com.agon.app.ui.screens.BackgroundPickerScreen
import com.agon.app.ui.screens.BrowserScreen
import com.agon.app.ui.screens.HomeScreen
import com.agon.app.ui.screens.PermissionScreen
import com.agon.app.ui.screens.SettingsScreen
import com.agon.app.ui.theme.AgonAppTheme
import com.agon.app.util.PermissionHelper
import com.agon.app.viewmodel.FileViewModel
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val vm: FileViewModel = viewModel()
            val settings by vm.settings.collectAsState()
            AgonAppTheme(
                themeMode = settings.themeMode,
                paletteId = settings.paletteId,
            ) {
                MainApp(vm)
            }
        }
    }
}

private data class TabItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
)

@Composable
fun MainApp(vm: FileViewModel) {
    val navController = rememberNavController()
    val settings by vm.settings.collectAsState()
    val message by vm.message.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    var hasAccess by remember { mutableStateOf(PermissionHelper.hasStorageAccess(context)) }
    var skipPermission by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) {
        hasAccess = PermissionHelper.hasStorageAccess(context)
        vm.refreshShortcuts()
        vm.refreshStorage()
        vm.loadCurrent()
    }

    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            vm.consumeMessage()
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomBar = currentRoute in listOf("home", "browser", "settings") &&
        (hasAccess || skipPermission)

    val tabs = listOf(
        TabItem("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
        TabItem("browser", "Files", Icons.Filled.Folder, Icons.Outlined.Folder),
        TabItem("settings", "Settings", Icons.Filled.Settings, Icons.Outlined.Settings),
    )

    fun openFile(item: FileItem) {
        val encoded = URLEncoder.encode(item.path, StandardCharsets.UTF_8.toString())
        navController.navigate("player/$encoded")
    }

    AppBackground(
        backgroundPath = settings.backgroundImagePath,
        dim = settings.backgroundDim,
    ) {
        if (!hasAccess && !skipPermission) {
            PermissionScreen(
                onRequestLegacy = {
                    permissionLauncher.launch(PermissionHelper.legacyPermissions())
                },
                onContinue = {
                    skipPermission = true
                    hasAccess = PermissionHelper.hasStorageAccess(context)
                    vm.refreshShortcuts()
                    vm.loadCurrent()
                },
            )
            LaunchedEffect(Unit) {
                while (isActive) {
                    delay(900)
                    val now = PermissionHelper.hasStorageAccess(context)
                    if (now) {
                        hasAccess = true
                        vm.refreshShortcuts()
                        vm.refreshStorage()
                        vm.loadCurrent()
                        break
                    }
                }
            }
        } else {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = Color.Transparent,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                bottomBar = {
                    AnimatedVisibility(
                        visible = showBottomBar,
                        enter = slideInVertically { it } + fadeIn(),
                        exit = slideOutVertically { it } + fadeOut(),
                    ) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                        ) {
                            tabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(tab.route) {
                                            popUpTo(navController.graph.findStartDestination().id) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label,
                                        )
                                    },
                                    label = { Text(tab.label) },
                                )
                            }
                        }
                    }
                },
            ) { innerPadding ->
                Box(modifier = Modifier.padding(innerPadding)) {
                    NavHost(
                        navController = navController,
                        startDestination = "home",
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        composable("home") {
                            HomeScreen(
                                vm = vm,
                                onOpenBrowser = {
                                    navController.navigate("browser") {
                                        launchSingleTop = true
                                    }
                                },
                                onOpenPath = { path -> vm.navigateTo(path) },
                                onOpenFile = { openFile(it) },
                                onOpenCategory = { kind, title -> vm.openCategory(kind, title) },
                            )
                        }
                        composable("browser") {
                            BrowserScreen(
                                vm = vm,
                                onOpenFile = { openFile(it) },
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                vm = vm,
                                onPickBackground = {
                                    navController.navigate("bg_picker")
                                },
                            )
                        }
                        composable("bg_picker") {
                            BackgroundPickerScreen(
                                vm = vm,
                                onPicked = { path ->
                                    vm.setBackgroundImage(path)
                                    navController.popBackStack()
                                },
                                onCancel = {
                                    navController.popBackStack()
                                },
                            )
                        }
                        composable(
                            route = "player/{path}",
                            arguments = listOf(navArgument("path") { type = NavType.StringType }),
                        ) { entry ->
                            val encoded = entry.arguments?.getString("path").orEmpty()
                            val path = URLDecoder.decode(encoded, StandardCharsets.UTF_8.toString())
                            val kind = remember(path) { FileItem(File(path)).kind }
                            val text = remember(path, kind) {
                                if (kind == FileKind.TEXT || kind == FileKind.CODE || kind == FileKind.MODEL_3D) {
                                    vm.readText(path)
                                } else {
                                    null
                                }
                            }
                            val hex = remember(path, kind) {
                                if (kind == FileKind.PDF || kind == FileKind.OTHER || kind == FileKind.ARCHIVE) {
                                    vm.readHex(path)
                                } else {
                                    null
                                }
                            }
                            UniversalPlayerScreen(
                                path = path,
                                textContent = text,
                                hexContent = hex,
                                onBack = { navController.popBackStack() },
                            )
                        }
                    }
                }
            }
        }
    }
}
