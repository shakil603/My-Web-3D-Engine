package com.agon.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.data.FileItem
import com.agon.app.data.FileKind
import com.agon.app.ui.components.CategoryTile
import com.agon.app.ui.components.FileListRow
import com.agon.app.ui.components.ShortcutChip
import com.agon.app.ui.components.StorageCard
import com.agon.app.viewmodel.FileViewModel

@Composable
fun HomeScreen(
    vm: FileViewModel,
    onOpenBrowser: () -> Unit,
    onOpenPath: (String) -> Unit,
    onOpenFile: (FileItem) -> Unit,
    onOpenCategory: (FileKind, String) -> Unit,
) {
    val storage by vm.storageInfo.collectAsState()
    val shortcuts by vm.shortcuts.collectAsState()
    val settings by vm.settings.collectAsState()
    val favorites = vm.favoriteItems()
    val recents = vm.recentItems()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Column(modifier = Modifier.padding(bottom = 8.dp, top = 4.dp)) {
                Text("File", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Browse, preview & play anything",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item { StorageCard(info = storage) }
        item { SectionTitle("Quick access") }
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 4.dp),
            ) {
                items(shortcuts, key = { it.id }) { sc ->
                    val icon = when (sc.id) {
                        "downloads" -> Icons.Default.Download
                        "dcim" -> Icons.Default.PhotoCamera
                        "pictures" -> Icons.Default.Image
                        "movies" -> Icons.Default.Movie
                        "music" -> Icons.Default.MusicNote
                        "documents" -> Icons.Default.Description
                        "internal" -> Icons.Default.Storage
                        else -> Icons.Default.Folder
                    }
                    ShortcutChip(
                        title = sc.title,
                        icon = icon,
                        onClick = {
                            onOpenPath(sc.path)
                            onOpenBrowser()
                        },
                    )
                }
            }
        }
        item { SectionTitle("Categories") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CategoryTile(
                        title = "Images", subtitle = "Photos & art",
                        icon = Icons.Default.Image, accent = Color(0xFF4CAF50),
                        onClick = { onOpenCategory(FileKind.IMAGE, "Images"); onOpenBrowser() },
                        modifier = Modifier.weight(1f),
                    )
                    CategoryTile(
                        title = "Videos", subtitle = "Movies & clips",
                        icon = Icons.Default.Movie, accent = Color(0xFFE91E63),
                        onClick = { onOpenCategory(FileKind.VIDEO, "Videos"); onOpenBrowser() },
                        modifier = Modifier.weight(1f),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CategoryTile(
                        title = "Audio", subtitle = "Music & voice",
                        icon = Icons.Default.AudioFile, accent = Color(0xFF9C27B0),
                        onClick = { onOpenCategory(FileKind.AUDIO, "Audio"); onOpenBrowser() },
                        modifier = Modifier.weight(1f),
                    )
                    CategoryTile(
                        title = "Documents", subtitle = "Text & notes",
                        icon = Icons.Default.Description, accent = Color(0xFF607D8B),
                        onClick = { onOpenCategory(FileKind.TEXT, "Documents"); onOpenBrowser() },
                        modifier = Modifier.weight(1f),
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CategoryTile(
                        title = "Code", subtitle = "Source files",
                        icon = Icons.Default.Code, accent = Color(0xFF00BCD4),
                        onClick = { onOpenCategory(FileKind.CODE, "Code"); onOpenBrowser() },
                        modifier = Modifier.weight(1f),
                    )
                    CategoryTile(
                        title = "3D Models", subtitle = "OBJ, STL, GLTF",
                        icon = Icons.Default.ViewInAr, accent = Color(0xFFFF9800),
                        onClick = { onOpenCategory(FileKind.MODEL_3D, "3D Models"); onOpenBrowser() },
                        modifier = Modifier.weight(1f),
                    )
                }
                CategoryTile(
                    title = "PDFs", subtitle = "Portable documents",
                    icon = Icons.Default.PictureAsPdf, accent = Color(0xFFF44336),
                    onClick = { onOpenCategory(FileKind.PDF, "PDFs"); onOpenBrowser() },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        if (favorites.isNotEmpty()) {
            item { SectionTitle("Favorites", showStar = true) }
            items(favorites.take(8), key = { "fav-${it.path}" }) { item ->
                FileListRow(
                    item = item, selected = false, selectionMode = false, isFavorite = true,
                    onClick = {
                        if (item.isDirectory) { onOpenPath(item.path); onOpenBrowser() }
                        else onOpenFile(item)
                    },
                    onLongClick = { vm.toggleFavorite(item.path) },
                )
            }
        }
        if (recents.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SectionTitle("Recent")
                    TextButton(onClick = { vm.clearRecents() }) { Text("Clear") }
                }
            }
            items(recents.take(10), key = { "rec-${it.path}" }) { item ->
                FileListRow(
                    item = item, selected = false, selectionMode = false,
                    isFavorite = settings.favorites.contains(item.path),
                    onClick = {
                        if (item.isDirectory) { onOpenPath(item.path); onOpenBrowser() }
                        else onOpenFile(item)
                    },
                    onLongClick = { },
                )
            }
        }
        item { Spacer(modifier = Modifier.height(72.dp)) }
    }
}

@Composable
private fun SectionTitle(title: String, showStar: Boolean = false) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp),
    ) {
        if (showStar) {
            Icon(
                Icons.Default.Star, contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.padding(end = 6.dp),
            )
        }
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}
